//
//  LBResetLabelViewController.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/12/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBResetLabelViewController.h"

#import "LBResetLabelCell.h"

#import "TPKeyboardAvoidingTableView.h"

#import "LBCommonHeader.h"
#import "UIColor+Common.h"
#import "UITableView+Common.h"
#import "UIBarButtonItem+Common.h"


#define kLBCellIdentifier_ResetLabelCell @"ResetLabelCell"

@interface LBResetLabelViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
{
    NSString *_tempStr;
}

@property (nonatomic, weak) UITextField *mCurrentTextField;

@property (strong, nonatomic) TPKeyboardAvoidingTableView *myTableView;

@end

@implementation LBResetLabelViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"重命名标签";
    self.navigationController.title = @"重命名标签";
    
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithBtnTitle:@"取消" target:self action:@selector(cancelBtnClick)];
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithBtnTitle:@"完成" target:self action:@selector(okBtnClick)];
    self.navigationItem.rightBarButtonItem.enabled = FALSE;
    
    self.view.backgroundColor = kColorTableSectionBg;
    
    _myTableView =
    ({
        TPKeyboardAvoidingTableView *tableView = [[TPKeyboardAvoidingTableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        tableView.backgroundColor = kColorTableSectionBg;
        tableView.delegate = self;
        tableView.dataSource = self;
        [tableView registerClass:[LBResetLabelCell class] forCellReuseIdentifier:kLBCellIdentifier_ResetLabelCell];
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:tableView];

        tableView;
    });
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    _myTableView.delegate = nil;
    _myTableView.dataSource = nil;
}

#pragma mark - click
- (void)cancelBtnClick
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)okBtnClick
{
    if (_tempStr.length > 0)
    {
        if (_ptLabel)
        {
            _ptLabel.name = _tempStr;
            
            [self refreshUserDefault:_ptLabel];
            
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

- (void)refreshUserDefault:(LBTag* )tag
{
    NSArray* arr = [[NSUserDefaults standardUserDefaults] objectForKey:LBTagsManagerMark];
    
    NSMutableArray* mutArr = [NSMutableArray array];
    
    for (NSDictionary* dic in arr)
    {
        [mutArr addObject:[dic mutableCopy]];
    }
    
    [mutArr enumerateObjectsUsingBlock:^(NSMutableDictionary* dic, NSUInteger idx, BOOL* stop){
        // ID相同，赶紧替换.
        if ([[dic objectForKey:@"id"] intValue] == [tag.id intValue])
        {
            // 这里坑啊.NSUserDefault返回过来的统统不可变.
            [dic setObject:tag.name forKey:@"name"];
            
            *stop = YES;
        }
    }];
    
    [[NSUserDefaults standardUserDefaults] setObject:mutArr forKey:LBTagsManagerMark];
}



#pragma mark - UITableViewDataSource & UITableViewDelegate.

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LBResetLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:kLBCellIdentifier_ResetLabelCell forIndexPath:indexPath];
    [tableView addLineforPlainCell:cell forRowAtIndexPath:indexPath withLeftSpace:kPaddingLeftWidth];
    cell.labelField.delegate = self;
    [cell.labelField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    cell.backgroundColor = kColorTableBG;
    cell.labelField.text = _ptLabel.name;
    return cell;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [LBResetLabelCell cellHeight];
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return FALSE;
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    self.mCurrentTextField = textField;
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return YES;
}

- (void)textFieldDidChange:(UITextField *)textField
{
    _tempStr = textField.text;
    if (_tempStr.length > 0) {
        self.navigationItem.rightBarButtonItem.enabled = [_tempStr isEqualToString:_ptLabel.name] ? FALSE : TRUE;
    } else {
        self.navigationItem.rightBarButtonItem.enabled = FALSE;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self.mCurrentTextField resignFirstResponder];
}


@end
