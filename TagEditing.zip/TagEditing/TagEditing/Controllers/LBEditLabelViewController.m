//
//  LBEditLabelViewController.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/12/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBEditLabelViewController.h"
#import "LBResetLabelViewController.h"

#import "LBTag.h"

#import "LBEditLabelCell.h"
#import "LBEditLabelHeadCell.h"

#import <BlocksKit.h>
#import "TPKeyboardAvoidingTableView.h"

#import "LBCommonHeader.h"
#import "UIColor+Common.h"
#import "NSString+Common.h"
#import "UITableView+Common.h"
#import "UIActionSheet+Common.h"
#import "UIBarButtonItem+Common.h"

#define kLBCellIdentifier_EditLabelCell @"LBEditLabelCell"
#define kLBCellIdentifier_EditLabelHeadCell @"LBEditLabelHeadCell"

@interface LBEditLabelViewController () <UITableViewDataSource, UITableViewDelegate, SWTableViewCellDelegate, UITextFieldDelegate>

@property (strong, nonatomic) NSString *tagNameToAdd;
@property (strong, nonatomic) NSMutableArray *tagList, *selectedTags;
@property (strong, nonatomic) TPKeyboardAvoidingTableView *myTableView;

@end

@implementation LBEditLabelViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)setOrignalTags:(NSArray *)orignalTags
{
    _orignalTags = orignalTags;
    if (_orignalTags.count > 0)
    {
        _selectedTags = [_orignalTags mutableCopy];
    }
    else
    {
        _selectedTags = [NSMutableArray new];
    }
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = @"标签管理";
    _tagList = [NSMutableArray array];
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithBtnTitle:@"保存" target:self action:@selector(okBtnClick)];
    self.navigationItem.rightBarButtonItem.enabled = FALSE;
    
    self.view.backgroundColor = kColorTableSectionBg;
    _myTableView = ({
        TPKeyboardAvoidingTableView *tableView = [[TPKeyboardAvoidingTableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        tableView.backgroundColor = kColorTableSectionBg;
        tableView.delegate = self;
        tableView.dataSource = self;
        [tableView registerClass:[LBEditLabelHeadCell class] forCellReuseIdentifier:kLBCellIdentifier_EditLabelHeadCell];
        [tableView registerClass:[LBEditLabelCell class] forCellReuseIdentifier:kLBCellIdentifier_EditLabelCell];
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:tableView];
        tableView;
    });
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // 修改成，从数据库获取.
    NSMutableArray* arr = [[NSUserDefaults standardUserDefaults] objectForKey:LBTagsManagerMark];
    
    [_tagList removeAllObjects];
    
    for (NSMutableDictionary* dic in arr)
    {
        LBTag* tag = [LBTag tagWithName:[dic objectForKey:@"name"]];
        tag.id = [dic objectForKey:@"id"];
        tag.color = [dic objectForKey:@"color"];
        
        [_tagList addObject:tag];
    }
    
    [self.myTableView reloadData];
}



#pragma mark - click

- (void)okBtnClick
{
    if (self.tagsChangedBlock)
    {
        self.tagsChangedBlock(self, _selectedTags);
    }
}


- (void)addBtnClick:(UIButton *)sender
{
    [self.view endEditing:YES];
    
    if (_tagNameToAdd.length > 0)
    {
        LBTag *curTag = [LBTag tagWithName:_tagNameToAdd];
        curTag.id = [NSNumber numberWithInt:[self obtainFromTaglist]];
        
        [self.tagList addObject:curTag];
        self.tagNameToAdd = @"";
        [self.myTableView reloadData];
        sender.enabled = FALSE;
        
        
        // 更新本地UserDefaults.
        [[NSUserDefaults standardUserDefaults] setObject:[self obtainTagManagerDictionary:_tagList] forKey:LBTagsManagerMark];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
}


- (int)obtainFromTaglist
{
     __block int max = 0;
    
    [_tagList enumerateObjectsUsingBlock:^(LBTag* tag, NSUInteger idx, BOOL* stop){
    
        int temp = [tag.id intValue];
        
        if (temp > max)
        {
            max = temp;
        }
    }];
    
    return ++max;
}


- (NSMutableArray *)obtainTagManagerDictionary:(NSMutableArray *)array
{
    NSMutableArray* arr = [NSMutableArray array];
    
    [array enumerateObjectsUsingBlock:^(LBTag* tag, NSUInteger idx, BOOL* stop){
        
        [arr addObject:[@{@"id":tag.id, @"name":tag.name, @"color":tag.color} mutableCopy]];
    
    }];
    
    return arr;
}


#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _tagList.count > 0 ? 2 : 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger row = 1;
    if (section == 1)
    {
        row = _tagList.count;
    }
    return row;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        LBEditLabelHeadCell *cell = [tableView dequeueReusableCellWithIdentifier:kLBCellIdentifier_EditLabelHeadCell forIndexPath:indexPath];
        [cell.addBtn addTarget:self action:@selector(addBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        cell.labelField.text = self.tagNameToAdd;
        cell.labelField.delegate = self;
        [cell.labelField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        [tableView addLineforPlainCell:cell forRowAtIndexPath:indexPath withLeftSpace:kPaddingLeftWidth];
        return cell;
    }
    else
    {
        LBTag *ptLabel = _tagList[indexPath.row];
        
        LBEditLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:kLBCellIdentifier_EditLabelCell forIndexPath:indexPath];
        [cell setRightUtilityButtons:[self rightButtons] WithButtonWidth:[LBEditLabelCell cellHeight]];
        cell.delegate = self;
        
        BOOL selected = FALSE;
        for (LBTag *lbl in _selectedTags)
        {
            if ([lbl.id integerValue] == [ptLabel.id integerValue])
            {
                selected = TRUE;
                break;
            }
        }
        [cell setTag:ptLabel andSelected:selected];
        
        [tableView addLineforPlainCell:cell forRowAtIndexPath:indexPath withLeftSpace:kPaddingLeftWidth];
        return cell;
    }
}


#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [LBEditLabelCell cellHeight];
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section > 0)
    {
        return TRUE;
    }
    return FALSE;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section > 0)
    {
        LBEditLabelCell *cell = (LBEditLabelCell *)[tableView cellForRowAtIndexPath:indexPath];
        cell.selectBtn.selected = !cell.selectBtn.selected;
        
        LBTag *tagInSelected = [LBTag tags:_selectedTags hasTag:_tagList[indexPath.row]];
        
        if (cell.selectBtn.selected && !tagInSelected)
        {
            [_selectedTags addObject:_tagList[indexPath.row]];
        }
        else if (!cell.selectBtn.selected && tagInSelected)
        {
            [_selectedTags removeObject:tagInSelected];
        }
        self.navigationItem.rightBarButtonItem.enabled = ![LBTag tags:_selectedTags isEqualTo:_orignalTags];
    }
}



- (NSArray *)rightButtons
{
    NSMutableArray *rightUtilityButtons = [NSMutableArray new];
    [rightUtilityButtons sw_addUtilityButtonWithColor:[UIColor colorWithHexString:@"0xe6e6e6"] icon:[UIImage imageNamed:@"icon_file_cell_rename"]];
    [rightUtilityButtons sw_addUtilityButtonWithColor:[UIColor colorWithHexString:@"0xff5846"] icon:[UIImage imageNamed:@"icon_file_cell_delete"]];
    return rightUtilityButtons;
}


#pragma mark - SWTableViewCellDelegate

- (BOOL)swipeableTableViewCellShouldHideUtilityButtonsOnSwipe:(SWTableViewCell *)cell
{
    return YES;
}

- (BOOL)swipeableTableViewCell:(SWTableViewCell *)cell canSwipeToState:(SWCellState)state
{
    return YES;
}


- (void)swipeableTableViewCell:(SWTableViewCell *)cell didTriggerRightUtilityButtonWithIndex:(NSInteger)index
{
    [cell hideUtilityButtonsAnimated:YES];
    
    NSIndexPath *indexPath = [self.myTableView indexPathForCell:cell];
    
    if (index == 0)
    {
        [self renameBtnClick:indexPath.row];
    }
    else
    {
        __weak typeof(self) weakSelf = self;
        LBTag *ptLabel = [_tagList objectAtIndex:indexPath.row];
        NSString *tip = [NSString stringWithFormat:@"确定要删除标签:%@？", ptLabel.name];
        
        UIActionSheet *actionSheet = [UIActionSheet bk_actionSheetCustomWithTitle:tip buttonTitles:nil destructiveTitle:@"确认删除" cancelTitle:@"取消" andDidDismissBlock:^(UIActionSheet *sheet, NSInteger index) {
            if (index == 0)
            {
                [weakSelf deleteBtnClick:indexPath.row];
            }
        }];
        [actionSheet showInView:self.view];
    }
}


- (void)renameBtnClick:(NSInteger)index
{
    LBResetLabelViewController *vc = [[LBResetLabelViewController alloc] init];
    vc.ptLabel = [_tagList objectAtIndex:index];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)deleteBtnClick:(NSInteger)index
{
    [self deleteLabel:index];
}


- (void)deleteLabel:(NSInteger)index
{
    LBTag *lbl = _tagList[index];
    for (LBTag *tempLbl in _selectedTags)
    {
        if ([tempLbl.id integerValue] == [lbl.id integerValue])
        {
            [_selectedTags removeObject:tempLbl];
            self.navigationItem.rightBarButtonItem.enabled = YES;
            break;
        }
    }
    [self.tagList removeObjectAtIndex:index];
    [self.myTableView reloadData];
    
    [self refreshUserDefault:lbl];
}


- (void)refreshUserDefault:(LBTag* )tag
{
    NSArray* arr = [[NSUserDefaults standardUserDefaults] objectForKey:LBTagsManagerMark];
    
    NSMutableArray* mutArr = [NSMutableArray array];
    
    for (NSDictionary* dic in arr)
    {
        [mutArr addObject:[dic mutableCopy]];
    }
    
    
    [mutArr enumerateObjectsUsingBlock:^(NSMutableDictionary* dic, NSUInteger idx, BOOL* stop){
        
        // ID相同，赶紧删除.
        if ([[dic objectForKey:@"id"] intValue] == [tag.id intValue])
        {
            
            [mutArr removeObject:dic];
            
            *stop = YES;
        }
    }];
    
    [[NSUserDefaults standardUserDefaults] setObject:mutArr forKey:LBTagsManagerMark];
}


#pragma mark - UITextFieldDelegate

- (void)textFieldDidChange:(UITextField *)textField
{
    _tagNameToAdd = [textField.text trimWhitespace];
    BOOL enabled = _tagNameToAdd.length > 0 ? TRUE : FALSE;
    if (enabled)
    {
        for (LBTag *lbl in _tagList)
        {
            if ([lbl.name isEqualToString:_tagNameToAdd])
            {
                enabled = FALSE;
                break;
            }
        }
    }
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    LBEditLabelHeadCell *cell = (LBEditLabelHeadCell *)[_myTableView cellForRowAtIndexPath:indexPath];
    cell.addBtn.enabled = enabled;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

@end















