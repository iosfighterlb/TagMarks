//
//  LBNormalTagViewController.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/11/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBNormalTagViewController.h"

#import "LBTag.h"
#import "LBTagsView.h"
#import "LBCommonHeader.h"
#import "LBEditLabelViewController.h"

@interface LBNormalTagViewController ()

@property (nonatomic, strong) LBTagsView* tagsView;
@property (nonatomic, strong) NSArray *tagsArray;

@end

@implementation LBNormalTagViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
 
    if (!_tagsView)
    {
        _tagsView = [LBTagsView viewWithTags:nil];
        [_tagsView setFrame:CGRectMake(0, 10 + 20 + 40, kScreen_Width, [LBTagsView getHeightForTags:_tagsArray])];
        
        __weak typeof(self) weakSelf = self;
        _tagsView.addTagBlock = ^(){
          
            [weakSelf presentToTagsViewController];

        };
        
        _tagsView.deleteTagBlock = ^(LBTag *curTag){
            
        };
        
        [self.view addSubview:_tagsView];
    }
    
    [_tagsView setTags:_tagsArray];
}


- (void)presentToTagsViewController
{
    LBEditLabelViewController *vc = [LBEditLabelViewController new];
    vc.orignalTags = _tagsArray;
    
    __weak typeof(self) weakSelf = self;
    vc.tagsChangedBlock = ^(LBEditLabelViewController *vc, NSMutableArray *selectedTags){
    
        [weakSelf tagsHasChanged:selectedTags fromVC:vc];
    };
    
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)tagsHasChanged:(NSMutableArray *)selectedTags fromVC:(LBEditLabelViewController *)vc
{
    
    if ([LBTag tags:[_tagsArray mutableCopy] isEqualTo:selectedTags])
    {
        [vc.navigationController popViewControllerAnimated:YES];        // 如果没有变化.退出栈.
    }
    else
    {
        _tagsArray = (NSArray *)selectedTags;
        
        [_tagsView setTags:_tagsArray];
        [vc.navigationController popViewControllerAnimated:YES];
    }
    
}

@end







// 御用数据:
//    LBTag* tag1 = [[LBTag alloc] init];
//    tag1.id = @1000;
//    tag1.name = @"C";
//    tag1.color = @"#5427DC";
//
//    LBTag* tag2 = [[LBTag alloc] init];
//    tag2.id = @1001;
//    tag2.name = @"Java";
//    tag2.color = @"#681FA7";
//
//    LBTag* tag3 = [[LBTag alloc] init];
//    tag3.id = @1002;
//    tag3.name = @"C++";
//    tag3.color = @"#121FA2";
//
//    LBTag* tag4 = [[LBTag alloc] init];
//    tag4.id = @1003;
//    tag4.name = @"Swift";
//    tag4.color = @"#eeeeee";
//
//    LBTag* tag5 = [[LBTag alloc] init];
//    tag5.id = @1004;
//    tag5.name = @"Ruby";
//    tag5.color = @"#58FA32";
//
//    LBTag* tag6 = [[LBTag alloc] init];
//    tag6.id = @1005;
//    tag6.name = @"Python";
//    tag6.color = @"#FG32H8";
//
//    LBTag* tag7 = [[LBTag alloc] init];
//    tag7.id = @1006;
//    tag7.name = @"Object-C";
//    tag7.color = @"#89MN32";
//
//    _tagsArray = @[tag1, tag2, tag3, tag4, tag5, tag6, tag7];


