//
//  LBTag.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/6/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//


#import "UIColor+Common.h"

#import "LBTag.h"

@implementation LBTag

- (instancetype)init
{
    self = [super init];
    if (self) {
        _id = @(0);
        _name = @"";
    }
    return self;
}


- (NSString *)color
{
    if (_color.length <= 0)
    {
        _color = [NSString stringWithFormat:@"#%@", [[UIColor randomColor] hexStringFromColor]];
    }
    return _color;
}


+ (instancetype)tagWithName:(NSString *)name
{
    LBTag *tag = [[self alloc] init];
    tag.name = name;
    return tag;
}




+ (BOOL)tags:(NSArray *)aTags isEqualTo:(NSArray *)bTags
{
    if (aTags.count == 0 && bTags.count == 0)
    {
        return YES;
    }
    
    BOOL isSame = YES;
    if (aTags.count != bTags.count ||                   // 首先你肯定要数量相同啦！
        (aTags.count == 0 && bTags.count == 0))
    {
        isSame = NO;
    }
    else
    {
        for (LBTag *mdTag in aTags)
        {
            BOOL tempHasOne = NO;
            for (LBTag *tempTag in bTags)
            {
                tempHasOne = (tempTag.id.integerValue == mdTag.id.integerValue);  // 用这样的逻辑运算式，减少if句柄
                if (tempHasOne)
                {
                    break;
                }
            }
            isSame = tempHasOne;
            if (!isSame)
            {
                break;
            }
        }
    }
    return isSame;
}




+ (instancetype)tags:(NSArray *)aTags hasTag:(LBTag *)curTag
{
    LBTag *resultTag = nil;
    
    for (LBTag *tempTag in aTags)
    {
        if (tempTag.id.integerValue == curTag.id.integerValue)
        {
            resultTag = tempTag;
            
            break;
        }
    }
    return resultTag;
}


@end












































/**
 * * * * * * * * * * * * * * * * * * * * *
 
 
 
 
@interface LBPerson : NSObject

@property (readwrite, nonatomic, strong) NSString *name;
 
@end
 
 

LBPerson *person1 , *person2 , *person3 , *person4 , *person5 ;
LBPerson *person6 , *person7 , *person8 , *person9 , *person10 ;

XXXXXXXXXXXXXXX经过一系列操作XXXXXXXXXX
 
NSArray *arraryA = @[person1 , person2 , person3 , person4 , person5];
NSArray *arraryB = @[person6 , person7 , person8 , person9 , person10];
 
 
问题：
现在需要编写一个数组判断器，根据person来判断两个数组是否相同，怎么补全这个函数？
并且，这个算法分几种情况，这些情况最好的排序条件是什么，该怎么优化？
 
+ (BOOL)array:(NSArray *)arrA isEqualTo:(NSArray *)arrB
 
 
 
 
答案：
+ (BOOL)array:(NSArray *)arrA isEqualTo:(NSArray *)arrB
 {
    if (arrA.count == 0 && arrB.count == 0)         //两者为空，为相同
    {
        return YES;
    }
 
    BOOL isSame = YES;
    if (arrA.count != arrB.count )                  //如果基本的数量都不同，那肯定不同
    {
        isSame = NO;
    }
    else
    {
        for (LBPerson *person in arrA)
        {
            BOOL tempHasOne = NO;
            
            for (LBPerson *tmpPerson in arrB)
            {
                tempHasOne = [tmpPerson.name isEqualToString person.name];  // 用这样的逻辑运算式，减少if句柄
                if (tempHasOne)
                {
                    break;              // 判断相同，数组B停止循环.
                }
            }
            isSame = tempHasOne;
            if (!isSame)
            {
                break;
            }
        }
    }
    return isSame;
}


算法最好的情况：
相同：
数组需要有序并且对齐循环，B数组每次循环都对齐break
不同：
数组内元素需要全部不同B数组遍历全部，A数组比较一次即可
 
优化用，这个想法去优化即可 - - 关键字 ： 数组 有序
 
 
 * * * * * * * * * * * * * * * * * * * * *
 */
















/**
 * * * * * * * * * * * * * * * * * * * * *
 
 C 和 Java 作为例子.
 
 ProjectTag's description for id : 1644376
 ProjectTag's description for owner_id : 154295
 ProjectTag's description for count : 0
 ProjectTag's description for name : C
 ProjectTag's description for color : #5427DC
 
 ProjectTag's description for id : 1663599
 ProjectTag's description for owner_id : 154295
 ProjectTag's description for count : 0
 ProjectTag's description for name : Java
 ProjectTag's description for color : #681FA7
 
 * * * * * * * * * * * * * * * * * * * * *
 */