//
//  LBTag.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/6/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <Foundation/Foundation.h>

/**项目类型
 */
typedef NS_ENUM(NSUInteger, TagType){
    TagTypeTopic = 0,
    TagTypeTask,
};

@interface LBTag : NSObject

/** id 标签ID 
 */
@property (readwrite, nonatomic, strong) NSNumber *id;


/** 标签名字
 */
@property (readwrite, nonatomic, strong) NSString *name;

/** 标签颜色
 */
@property (readwrite, nonatomic, strong) NSString *color;


/** 标签生成器，在编辑标签中使用
 */
+ (instancetype)tagWithName:(NSString *)name;


/** 判断两个tag是否相同，这种自定义的Model是需要这类型的比较器的
 */
+ (BOOL)tags:(NSArray *)aTags isEqualTo:(NSArray *)bTags;

/** 返回一个tag实例，问题是hasTag？
 */
+ (instancetype)tags:(NSArray *)aTags hasTag:(LBTag *)curTag;

@end




/**
 * * * * * * * * * * * * * * * * * * * * *
 
 C 和 Java 作为例子.
 
 ProjectTag's description for id : 1644376
 ProjectTag's description for owner_id : 154295
 ProjectTag's description for count : 0
 ProjectTag's description for name : C
 ProjectTag's description for color : #5427DC
 
 ProjectTag's description for id : 1663599
 ProjectTag's description for owner_id : 154295
 ProjectTag's description for count : 0
 ProjectTag's description for name : Java
 ProjectTag's description for color : #681FA7
 
 * * * * * * * * * * * * * * * * * * * * *
 */

