//
//  LBResetLabelCell.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/12/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBResetLabelCell.h"

#import "LBCommonHeader.h"
#import "UIColor+Common.h"

@implementation LBResetLabelCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.accessoryType = UITableViewCellAccessoryNone;
        self.backgroundColor = [UIColor clearColor];
        // Initialization code
        if (!_labelField) {
            _labelField = [[UITextField alloc] initWithFrame:CGRectMake(kPaddingLeftWidth, 0, (kScreen_Width - kPaddingLeftWidth * 2), 44)];
            _labelField.textColor = [UIColor colorWithHexString:@"0x222222"];
            _labelField.font = [UIFont systemFontOfSize:16];
            _labelField.clearButtonMode = UITextFieldViewModeWhileEditing;
            [self.contentView addSubview:_labelField];
        }
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

+ (CGFloat)cellHeight
{
    return 44.0;
}

@end
