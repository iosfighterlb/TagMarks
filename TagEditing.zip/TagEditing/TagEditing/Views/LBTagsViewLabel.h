//
//  LBTagsViewLabel.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/7/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LBTag.h"

@interface LBTagsViewLabel : UILabel

/** LBTag Model.
 */
@property (nonatomic, strong) LBTag *curTag;

/** deleteBlock 操作.
 */
@property (nonatomic, copy) void (^deleteBlock) (LBTag *tag);

/** 初始化 .
 */
+ (instancetype)labelWithTag:(LBTag *)tag andDeleteBlock:(void (^)(LBTag *tag))block;

@end
