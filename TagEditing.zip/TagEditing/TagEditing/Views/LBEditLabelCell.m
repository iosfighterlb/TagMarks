//
//  LBEditLabelCell.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/11/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBEditLabelCell.h"
#import "LBTagsLabel.h"
#import "LBCommonHeader.h"

#import "UIView+Common.h"
#import "UIColor+Common.h"

@interface LBEditLabelCell () <SWTableViewCellDelegate>

@property (nonatomic, strong) LBTagsLabel* nameLbl;

@end

@implementation LBEditLabelCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.accessoryType = UITableViewCellAccessoryNone;
        self.backgroundColor = kColorTableBG;
        
        if (!_selectBtn) {
            _selectBtn = [[UIButton alloc] initWithFrame:CGRectMake(kScreen_Width - kPaddingLeftWidth - 24, 10, 24, 24)];
            [_selectBtn setImage:[UIImage imageNamed:@"tag_select_no"] forState:UIControlStateNormal];
            [_selectBtn setImage:[UIImage imageNamed:@"tag_select"] forState:UIControlStateSelected];
            _selectBtn.userInteractionEnabled = NO;
            [self.contentView addSubview:_selectBtn];
        }
    }
    return self;
}


- (void)setTag:(LBTag *)curTag andSelected:(BOOL)selected
{
    if (_nameLbl) {
        _nameLbl.curTag = curTag;
    }else{
        _nameLbl = [LBTagsLabel labelWithTag:curTag font:[UIFont systemFontOfSize:12] height:20 widthPadding:10];
        [_nameLbl setOrigin:CGPointMake(kPaddingLeftWidth, ([LBEditLabelCell cellHeight] - 22)/2)];
        [self.contentView addSubview:_nameLbl];
    }
    _selectBtn.selected = selected;
}

+ (CGFloat)cellHeight
{
    return 44.0;
}

@end
