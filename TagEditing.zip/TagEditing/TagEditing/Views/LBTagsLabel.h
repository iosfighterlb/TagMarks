//
//  LBTagsLabel.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/11/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LBTag.h"

@interface LBTagsLabel : UILabel

@property (strong, nonatomic) LBTag *curTag;
- (void)setup;//调整UI。设置 curTag 的时候会自动调整，其他属性默认不调整。

+ (instancetype)labelWithTag:(LBTag *)curTag font:(UIFont *)font height:(CGFloat)height widthPadding:(CGFloat)width_padding;

@end
