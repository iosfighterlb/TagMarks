//
//  LBResetLabelCell.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/12/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBResetLabelCell : UITableViewCell

@property (strong, nonatomic) UITextField *labelField;

+ (CGFloat)cellHeight;

@end
