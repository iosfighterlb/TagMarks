//
//  LBTagsView.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/5/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LBTag.h"

@interface LBTagsView : UIView

/** 装载tags的数组
 */
@property (nonatomic, strong) NSArray *tags;

/** 删除Tag的Block操作
 */
@property (nonatomic, copy) void (^deleteTagBlock)(LBTag *tag);

/** 添加Tag Block操作
 */
@property (nonatomic, copy) void (^addTagBlock)();

- (instancetype)initWithTags:(NSArray *)tags;
+ (instancetype)viewWithTags:(NSArray *)tags;
+ (CGFloat)getHeightForTags:(NSArray *)tags;

@end
