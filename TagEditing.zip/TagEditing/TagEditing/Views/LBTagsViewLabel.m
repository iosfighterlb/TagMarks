//
//  LBTagsViewLabel.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/7/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBTagsViewLabel.h"

#import "UIView+Common.h"
#import "UIColor+Common.h"
#import "NSString+Common.h"
#import "LBCommonHeader.h"

@implementation LBTagsViewLabel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.font = kLBTagsViewLabel_Font;
        self.textAlignment = NSTextAlignmentCenter;
        self.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        self.layer.cornerRadius = 2;
        
        
        // http://blog.lessfun.com/blog/2014/11/22/when-should-use-weakself-and-strongself-in-objc-block/
        
//        __weak typeof(self) weakSelf = self;
//        [self addPressMenuTitles:@[@"删除"] menuClickedBlock:^(NSInteger index, NSString *title) {
//            
//            __strong typeof(weakSelf) strongSelf = weakSelf;
//            if (strongSelf.deleteBlock)
//            {
//                strongSelf.deleteBlock(strongSelf.curTag);
//            }
//        }];
//        self.pressGR.minimumPressDuration = 0.2;//菜单更易弹出
    }
    return self;
}



+ (instancetype)labelWithTag:(LBTag *)tag andDeleteBlock:(void (^)(LBTag *))block
{
    LBTagsViewLabel *label = [LBTagsViewLabel new];
    label.curTag = tag;
    label.deleteBlock = block;
    return label;
}


- (void)setCurTag:(LBTag *)curTag
{
    _curTag = curTag;
    [self setup];
}


- (void)setup
{
    if (!self.curTag || self.curTag.name.length <= 0)
    {
        [self setSize:CGSizeZero];
        return;
    }
    
    UIColor *tagColor = self.curTag.color.length > 1? [UIColor colorWithHexString:[self.curTag.color stringByReplacingOccurrencesOfString:@"#" withString:@"0x"]] : [UIColor colorWithHexString:@"0x3bbd79"];
    self.layer.backgroundColor = tagColor.CGColor;
    self.textColor = [tagColor isDark]? [UIColor whiteColor]: [UIColor blackColor];
    
    CGSize constrainedSize = CGSizeMake(CGFLOAT_MAX, kLBTagsViewLabel_Height_Content);
    CGFloat fontWidth = [self.curTag.name getWidthWithFont:kLBTagsViewLabel_Font constrainedToSize:constrainedSize];
    // 字体宽度 + Padding(约莫10)  和  44来比
    CGFloat selfWidth = MAX(fontWidth + kLBTagsViewLabel_Padding_Content, kLBTagsViewLabel_MinWidth);
    
    [self setSize:CGSizeMake(selfWidth, kLBTagsViewLabel_Height_Content)];
    self.text = self.curTag.name;
}


@end








