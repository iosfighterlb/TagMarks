//
//  LBTagsView.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/5/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//


#import "LBTagsView.h"
#import "LBTag.h"
#import "LBTagsViewLabel.h"

#import "LBCommonHeader.h"

#import "UIView+Common.h"
#import "UIColor+Common.h"
#import "NSString+Common.h"

#import <BlocksKit.h>
#import <BlocksKit+UIKit.h>


@interface LBTagsView ()

/** 标签列表，可以增删
 */
@property (strong, nonatomic) NSMutableArray *tagLabelList;

/** 添加Tag按钮
 */
@property (strong, nonatomic) UIButton *addTagButton;

/** Tag
 */
@property (strong, nonatomic) UIImageView *tagIconView;

@end

@implementation LBTagsView


- (instancetype)initWithTags:(NSArray *)tags
{
    self = [super init];
    if (self)
    {
        _tagLabelList = [NSMutableArray new];
        self.tags = tags;
    }
    return self;
}

+ (instancetype)viewWithTags:(NSArray *)tags
{
    LBTagsView *tagsView = [[self alloc] initWithTags:tags];
    return tagsView;
}




/**
 * * * * * * * * * * * * * * * * * * * * *
 
 整个计算过程都是非常直观，先获取一个一行最大值：tagsWidth
 然后每次遍历计算出tags数组所拥有的长度，这里有一个不太合理的地方，一开始先全部遍历一遍
 每次都去判断CurX CurY Height
 如果超出一行，则CurY添加一行的高度30
 
 最后计算出所得高度.
 
 * * * * * * * * * * * * * * * * * * * * *
 */
+ (CGFloat)getHeightForTags:(NSArray *)tags
{
    CGFloat height = 0;
    
    // 标签数组存在内容
    if (tags.count > 0)
    {
        // 屏幕宽度 - 两倍左Padding - Icon宽度
        // 标准的添加标签长度
        CGFloat tagsWidth = kScreen_Width - 2*kPaddingLeftWidth - kLBTagsView_Padding_Icon;
        CGFloat curX = 0, curY = 0;
        
        for (LBTag *curTag in tags)
        {
            // 取  获取当前tag名字的宽度 + 标签的左右边距   和  44 的最大值
            CGSize constrainedSize = CGSizeMake(CGFLOAT_MAX, kLBTagsViewLabel_Height_Content);
            CGFloat curNameWidth = [curTag.name getWidthWithFont:kLBTagsViewLabel_Font
                                               constrainedToSize:constrainedSize];
            // 例如只有一个字母C，则取最小值44
            CGFloat curTagWidth = MAX(curNameWidth + kLBTagsViewLabel_Padding_Content, kLBTagsViewLabel_MinWidth);
            
            // curX 加上 哪个小加哪个  curTagWidth 与 tagsWidth
            // 这里为什么要标签比tagsWidth大的时候取tagsWidth，因为已经很大很大的时候
            // curX + tagsWidth > tagsWidth 是一个恒等式啦
            // 所以相当于直接过了.
            curX += MIN(curTagWidth, tagsWidth);
            
            if (curX > tagsWidth)
            {
                curY += kLBTagsView_Height_PerLine;
                curX = curTagWidth + kLBTagsViewLabel_Padding_Space;
            }
            else
            {
                curX += kLBTagsViewLabel_Padding_Space;
            }
            
            // 这里添加标签，单纯拿这几个字来量度尺寸
            CGFloat buttonWidth = [LBAddTagTitle getWidthWithFont:kLBTagsViewLabel_Font constrainedToSize:CGSizeMake(CGFLOAT_MAX, kLBTagsViewLabel_Height_Content)] + kLBTagsViewLabel_Padding_Content;
            
            if (curX + buttonWidth > tagsWidth)
            {
                curY += kLBTagsView_Height_PerLine;
            }
            height = curY + kLBTagsView_Height_PerLine;
        }
    }
    else
    {
        height =  kLBTagsView_Height_PerLine;
    }
    
    return height;
}





// 刷新 “添加标签”
- (void)p_refreshAddButtonHasTags:(BOOL)hasTags
{
    if (!_addTagButton)
    {
        _addTagButton = [UIButton new];
        _addTagButton.layer.cornerRadius = 2;
        _addTagButton.layer.borderColor = [UIColor colorWithHexString:@"0xdddddd"].CGColor;
        
        /*************************
        上GitHub的版本直接去掉这个用了三方的东西.
        但是用法要标留
         
        http://blog.lessfun.com/blog/2014/11/22/when-should-use-weakself-and-strongself-in-objc-block/
         
        // @weakify(self);       __weak typeof(self) weakSelf = self;
        // @strongify(self);     __strong typeof(weakSelf) strongSelf = weakSelf;
        
        __weak typeof(self) weakSelf = self;
        [_addTagButton bk_addEventHandler:^(id sender){         // 利用BlocksKit为UI添加事件
        
            __strong typeof(weakSelf) strongSelf = weakSelf;
            
            if (strongSelf.addTagBlock)
            {
                strongSelf.addTagBlock();
            }
        } forControlEvents:UIControlEventTouchUpInside];
         
        ***************************/
        
        [_addTagButton addTarget:self action:@selector(addTagButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_addTagButton];
    }
    
    NSString *buttonTitle = LBAddTagTitle;
    if (hasTags)
    {
        // 黑色圆框态.
        _addTagButton.layer.borderWidth = 0.5f;
        _addTagButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        _addTagButton.titleLabel.font = kLBTagsViewLabel_Font;
        [_addTagButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_addTagButton setTitleColor:[UIColor colorWithWhite:0 alpha:0.5] forState:UIControlStateHighlighted];
        
        CGFloat textWidth = [buttonTitle getWidthWithFont:kLBTagsViewLabel_Font constrainedToSize:CGSizeMake(CGFLOAT_MAX, kLBTagsViewLabel_Height_Content)];
        [_addTagButton setTitle:buttonTitle forState:UIControlStateNormal];
        [_addTagButton setImage:nil forState:UIControlStateNormal];
        [_addTagButton setTitleEdgeInsets:UIEdgeInsetsZero];
        [_addTagButton setSize:CGSizeMake(textWidth + kLBTagsViewLabel_Padding_Content, kLBTagsViewLabel_Height_Content)];
    }
    else
    {
        // 绿色初始态.
        _addTagButton.layer.borderWidth = 0.f;
        _addTagButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _addTagButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [_addTagButton setTitleColor:[UIColor colorWithHexString:@"0x3bbd79"] forState:UIControlStateNormal];
        [_addTagButton setTitleColor:[UIColor colorWithHexString:@"0x3bbd79" andAlpha:0.5] forState:UIControlStateHighlighted];
        
        [_addTagButton setSize:CGSizeMake(kScreen_Width - 2*kPaddingLeftWidth, kLBTagsViewLabel_Height_Content)];
        [_addTagButton setTitle:buttonTitle forState:UIControlStateNormal];
        [_addTagButton setImage:[UIImage imageNamed:@"project_tag_btn"] forState:UIControlStateNormal];
        [_addTagButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 5, 0, -5)];
    }
}


- (void)addTagButtonAction:(id)sender
{
    if (self.addTagBlock)
    {
        self.addTagBlock();
    }
}



/** Tag
 */
- (void)setTags:(NSArray *)tags
{
    _tags = tags;
    [self p_refreshAddButtonHasTags:_tags.count > 0];
    
    CGPoint curPoint = CGPointZero;
    
    if (_tags.count > 0)
    {
        // 将绿色图标换成灰色图标
        if (!_tagIconView)
        {
            _tagIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"project_tag_icon"]];
        }
        [_tagIconView setCenter:CGPointMake(kPaddingLeftWidth + CGRectGetWidth(_tagIconView.frame)/2, kLBTagsViewLabel_Height_Content/2)];
        [self addSubview:_tagIconView];
        
        
        // !!!!
        // 添加标签，这里算核心之地儿
        
        CGFloat leftX = kPaddingLeftWidth + kLBTagsView_Padding_Icon;           // 1. 找到标签右边的像素位置.
        CGFloat tagsWidth = kScreen_Width - kPaddingLeftWidth - leftX;          // 2. 计算出 减去左边标签处 减去最右边的15padding距离
        curPoint.x = leftX;                                                     // 3. 当前的point 为 leftX
        
        int index;
        
        for (index = 0; index < _tags.count; index ++)
        {
            LBTagsViewLabel *curLabel;
            
            // 嗨厉害，自身有一个属性变量 _tagLabelList
            // 传进来另外一个 _tags
            // 比较这个两个数量，从而可以删除掉如果减少掉的标签
            
            if (_tagLabelList.count > index)
            {
                curLabel = _tagLabelList[index];
                curLabel.curTag = _tags[index];
            }
            else
            {
                __weak typeof(self) weakSelf = self;
                curLabel = [LBTagsViewLabel labelWithTag:_tags[index] andDeleteBlock:^(LBTag *tag){
                
                    __strong typeof(weakSelf) strongSelf = weakSelf;
                    
                    if (strongSelf.deleteTagBlock)
                    {
                        strongSelf.deleteTagBlock(tag);
                    }
                }];
                [_tagLabelList addObject:curLabel];
            }
            
            CGFloat curPointRightX = curPoint.x + MIN(CGRectGetWidth(curLabel.frame), tagsWidth);
            
            // 长度大于一行，自动换行
            if (curPointRightX > kScreen_Width - kPaddingLeftWidth) {
                curPoint.x = leftX;
                curPoint.y += kLBTagsView_Height_PerLine;
            }
            
            [curLabel setOrigin:curPoint];
            [self addSubview:curLabel];
            
            //下一个点
            curPoint.x += CGRectGetWidth(curLabel.frame) + kLBTagsViewLabel_Padding_Space;
        }
        
        
        // 遍历完毕.
        if (_tagLabelList.count > index)
        {
            [_tagLabelList enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(UILabel *obj, NSUInteger idx, BOOL *stop) {
            
                // 倒序遍历，将超出的删除掉.
                if (idx >= index)
                {
                    [obj removeFromSuperview];
                }
                else
                {
                    *stop = YES;
                }
            }];
            [_tagLabelList removeObjectsInRange:NSMakeRange(index, _tagLabelList.count -index)];
        }
        
        
        // 最后才添加按钮.
        if (curPoint.x + CGRectGetWidth(self.addTagButton.frame) > kScreen_Width - kPaddingLeftWidth) {
            curPoint.x = leftX;
            curPoint.y += kLBTagsView_Height_PerLine;
        }
        [self.addTagButton setOrigin:curPoint];
    }
    else
    {
        // 标签Model 不存在标签，删除掉出了那个Button的所有标签.
        [self.subviews enumerateObjectsUsingBlock:^(UIView *obj, NSUInteger idx, BOOL *stop) {
            if (![obj isKindOfClass:[UIButton class]])
            {
                [obj removeFromSuperview];
            }
        }];
        
        // 清空数组内容.
        [_tagLabelList removeAllObjects];
        curPoint.x = kPaddingLeftWidth;
        [self.addTagButton setOrigin:curPoint];
    }
    
    [self setSize:CGSizeMake(kScreen_Width, curPoint.y + kLBTagsView_Height_PerLine)];
}


@end























































