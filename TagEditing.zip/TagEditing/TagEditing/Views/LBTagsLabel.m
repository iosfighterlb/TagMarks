//
//  LBTagsLabel.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/11/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBTagsLabel.h"
#import "UIView+Common.h"
#import "UIColor+Common.h"
#import "NSString+Common.h"

@interface LBTagsLabel ()

@property (assign, nonatomic) CGFloat height, width_padding;

@end

@implementation LBTagsLabel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.textAlignment = NSTextAlignmentCenter;
        self.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
        self.layer.cornerRadius = 2;
        _height = 20;
        _width_padding = 10;
    }
    return self;
}

- (void)setCurTag:(LBTag *)curTag{
    _curTag = curTag;
    [self setup];
}

+ (instancetype)labelWithTag:(LBTag *)curTag font:(UIFont *)font height:(CGFloat)height widthPadding:(CGFloat)width_padding{
    LBTagsLabel *label = [self new];
    
    label.font = font;
    label.height = height;
    label.width_padding = width_padding;
    label.curTag = curTag;
    
    return label;
}

- (void)setup{
    if (!self.curTag || self.curTag.name.length <= 0) {
        [self setSize:CGSizeZero];
        return;
    }
    UIColor *tagColor = self.curTag.color.length > 1? [UIColor colorWithHexString:[self.curTag.color stringByReplacingOccurrencesOfString:@"#" withString:@"0x"]]: [UIColor colorWithHexString:@"0x3bbd79"];
    self.layer.backgroundColor = tagColor.CGColor;
    self.textColor = [tagColor isDark]? [UIColor whiteColor]: [UIColor blackColor];
    
    CGFloat selfWidth = [self.curTag.name getWidthWithFont:self.font constrainedToSize:CGSizeMake(CGFLOAT_MAX, _height)] + _width_padding;
    [self setSize:CGSizeMake(selfWidth, _height)];
    self.text = self.curTag.name;
}


@end
