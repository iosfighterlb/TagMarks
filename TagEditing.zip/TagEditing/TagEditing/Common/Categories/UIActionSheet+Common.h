//
//  UIActionSheet+Common.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/12/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIActionSheet (Common)

+ (instancetype)bk_actionSheetCustomWithTitle:(NSString *)title buttonTitles:(NSArray *)buttonTitles destructiveTitle:(NSString *)destructiveTitle cancelTitle:(NSString *)cancelTitle andDidDismissBlock:(void (^)(UIActionSheet *sheet, NSInteger index))block;

@end
