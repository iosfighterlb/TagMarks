//
//  UIView+Common.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/7/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Common)

@property (strong, nonatomic) UIMenuController *menuVC;
@property (strong, nonatomic) UILongPressGestureRecognizer *pressGR;
@property (copy, nonatomic) void(^menuClickedBlock)(NSInteger index, NSString *title);



- (void)setSize:(CGSize)size;
- (void)setOrigin:(CGPoint)origin;


// 长按菜单
- (void)addPressMenuTitles:(NSArray *)menuTitles menuClickedBlock:(void(^)(NSInteger index, NSString *title))block;


@end
