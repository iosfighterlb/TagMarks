//
//  UIView+Common.m
//  TagEditing
//
//  Created by 卢祥庭 on 7/7/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "UIView+Common.h"
#import <objc/runtime.h>

@implementation UIView (Common)

static const NSString *kPressMenuSelectorPrefix = @"easePressMenuClicked_";
static char PressMenuTitlesKey, PressMenuBlockKey, PressMenuGestureKey, MenuVCKey;


- (void)setSize:(CGSize)size{
    CGRect frame = self.frame;
    frame.size.width = size.width;
    frame.size.height = size.height;
    self.frame = frame;
}


- (void)setOrigin:(CGPoint)origin{
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}


- (void)addPressMenuTitles:(NSArray *)menuTitles menuClickedBlock:(void(^)(NSInteger index, NSString *title))block{
    self.userInteractionEnabled = YES;
    self.menuClickedBlock = block;
    self.menuTitles = menuTitles;
    if (self.pressGR == nil) {
        self.pressGR = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handlePress:)];
    }
    [self addGestureRecognizer:self.pressGR];
}




#pragma mark SET_GET

- (void)setMenuTitles:(NSArray *)menuTitles{
    objc_setAssociatedObject(self, &PressMenuTitlesKey, menuTitles, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (NSArray *)menuTitles{
    return objc_getAssociatedObject(self, &PressMenuTitlesKey);
}


- (void)setMenuClickedBlock:(void (^)(NSInteger, NSString *))menuClickedBlock{
    objc_setAssociatedObject(self, &PressMenuBlockKey, menuClickedBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}





- (void)handlePress:(UIGestureRecognizer*)recognizer{
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        [self p_showMenu];
    }
}

- (void)p_showMenu{
    [self becomeFirstResponder];
    NSMutableArray *menuItems = [[NSMutableArray alloc] initWithCapacity:self.menuTitles.count];
    Class cls = [self class];
    SEL imp = @selector(pressMenuClicked:);
    for (int i=0; i<self.menuTitles.count; i++) {
        NSString *title = [self.menuTitles objectAtIndex:i];
        //注册名添加方法sel，sel的具体实现在imp(pressMenuClicked:)
        SEL sel = sel_registerName([[NSString stringWithFormat:@"%@%d:", kPressMenuSelectorPrefix, i] UTF8String]);
        class_addMethod(cls, sel, [cls instanceMethodForSelector:imp], "v@");
        UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:title action:sel];
        [menuItems addObject:menuItem];
    }
    UIMenuController *menu = [UIMenuController sharedMenuController];
    [menu setMenuItems:menuItems];
    [menu setTargetRect:self.frame inView:self.superview];
    [menu setMenuVisible:YES animated:YES];
    self.menuVC = menu;
}



- (void)pressMenuClicked:(id)sender {
    NSString *selStr = NSStringFromSelector(_cmd);
    NSString *indexStr = [selStr substringFromIndex:kPressMenuSelectorPrefix.length];
    NSInteger index = indexStr.integerValue;
    if (index >=0 && index<self.menuTitles.count) {
        NSString *title = [self.menuTitles objectAtIndex:index];
        if (self.menuClickedBlock) {
            self.menuClickedBlock(index, title);
        }
    }
}

@end
