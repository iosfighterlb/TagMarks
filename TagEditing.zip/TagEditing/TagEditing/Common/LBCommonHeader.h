//
//  LBCommonHeader.h
//  TagEditing
//
//  Created by 卢祥庭 on 7/6/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#ifndef LBCommonHeader_h
#define LBCommonHeader_h

#endif /* LBCommonHeader_h */



#define kPaddingLeftWidth 15.0

#define kLBTagsView_Padding_Icon 22.0
#define kLBTagsView_Height_PerLine 30.0

#define kLBTagsViewLabel_Font [UIFont systemFontOfSize:12]

// 添加标签内容的高度
#define kLBTagsViewLabel_Height_Content 22.0
#define kLBTagsViewLabel_MinWidth 44.0
#define kLBTagsViewLabel_Padding_Content 10.0

// 标签之间的间距
#define kLBTagsViewLabel_Padding_Space 5.0

#define LBAddTagTitle @"添加标签"


#define kScreen_Bounds [UIScreen mainScreen].bounds
#define kScreen_Height [UIScreen mainScreen].bounds.size.height
#define kScreen_Width [UIScreen mainScreen].bounds.size.width


#define kColor999 [UIColor colorWithHexString:@"0x999999"]
#define kColorTableBG [UIColor colorWithHexString:@"0xfafafa"]
#define kColorTableSectionBg [UIColor colorWithHexString:@"0xeeeeee"]



#define LBMainViewTagMark @"kLBMainViewTagMark"
#define LBTagsManagerMark @"kLBTagsManagerMark"






